import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';

const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.ALLOWED_ORIGIN?.split(',') ?? false }));
app.use(express.json({ limit: '4mb' }));
app.use(rateLimit({ windowMs: 60_000, limit: 30, standardHeaders: true, legacyHeaders: false }));

type Provider = 'openai' | 'gemini' | 'claude';
const systemPrompt = 'You are FRIDAY, a careful bilingual Persian-English personal assistant. Be concise and useful. Never claim a device action happened unless an authorized Android tool confirms it.';

async function askOpenAI(message: string): Promise<string> {
  const key = process.env.OPENAI_API_KEY;
  if (!key) throw new Error('openai_not_configured');
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: process.env.OPENAI_MODEL || 'gpt-4o-mini', messages: [
      { role: 'system', content: systemPrompt }, { role: 'user', content: message }
    ] })
  });
  const data: any = await response.json();
  if (!response.ok) throw new Error(data?.error?.message || 'openai_request_failed');
  return data.choices?.[0]?.message?.content || '';
}

async function askGemini(message: string): Promise<string> {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new Error('gemini_not_configured');
  const model = process.env.GEMINI_MODEL || 'gemini-2.0-flash';
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ systemInstruction: { parts: [{ text: systemPrompt }] }, contents: [{ role: 'user', parts: [{ text: message }] }] })
  });
  const data: any = await response.json();
  if (!response.ok) throw new Error(data?.error?.message || 'gemini_request_failed');
  return data.candidates?.[0]?.content?.parts?.map((p: any) => p.text || '').join('') || '';
}

async function askClaude(message: string): Promise<string> {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) throw new Error('claude_not_configured');
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({ model: process.env.CLAUDE_MODEL || 'claude-3-5-haiku-latest', max_tokens: 1500,
      system: systemPrompt, messages: [{ role: 'user', content: message }] })
  });
  const data: any = await response.json();
  if (!response.ok) throw new Error(data?.error?.message || 'claude_request_failed');
  return data.content?.map((p: any) => p.text || '').join('') || '';
}

app.get('/health', (_req, res) => res.json({
  ok: true, service: 'friday-api',
  providers: {
    openai: Boolean(process.env.OPENAI_API_KEY),
    gemini: Boolean(process.env.GEMINI_API_KEY),
    claude: Boolean(process.env.ANTHROPIC_API_KEY)
  }
}));

app.post('/v1/chat', async (req, res) => {
  const message = String(req.body?.message ?? '').trim();
  const provider = String(req.body?.provider ?? process.env.DEFAULT_PROVIDER ?? 'openai') as Provider;
  if (!message) return res.status(400).json({ error: 'message_required' });
  if (!['openai', 'gemini', 'claude'].includes(provider)) return res.status(400).json({ error: 'invalid_provider' });
  try {
    const reply = provider === 'openai' ? await askOpenAI(message)
      : provider === 'gemini' ? await askGemini(message) : await askClaude(message);
    res.json({ provider, reply });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'provider_error';
    console.error('provider_error', message);
    res.status(502).json({ error: message });
  }
});

const port = Number(process.env.PORT ?? 8080);
app.listen(port, () => console.log(`FRIDAY API listening on ${port}`));
