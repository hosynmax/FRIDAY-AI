package com.friday.assistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.tts.TextToSpeech
import java.util.Locale

class FridayActions(private val context: Context) {
    private var tts: TextToSpeech? = null
    init { tts = TextToSpeech(context) { status ->
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("fa", "IR")
    } }
    fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "friday-${System.currentTimeMillis()}")
    }
    fun stopSpeaking() { tts?.stop() }
    fun openWifiSettings() { context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun openBluetoothSettings() { context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun openCamera() { launch(Intent("android.media.action.IMAGE_CAPTURE")) }
    fun openCalculator() {
        val intent = context.packageManager.getLaunchIntentForPackage("com.google.android.calculator")
        if (intent != null) launch(intent) else launch(Intent(Settings.ACTION_SETTINGS))
    }
    fun setTimer(seconds: Int, label: String = "FRIDAY timer") {
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds.coerceAtLeast(1))
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
    private fun launch(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }
    fun close() { tts?.stop(); tts?.shutdown(); tts = null }
}
