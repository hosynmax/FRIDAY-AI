package com.friday.assistant

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class FridayItem(val id: Long, val title: String, val body: String, val kind: String, val createdAt: Long)

class FridayDatabase(context: Context) : SQLiteOpenHelper(context, "friday_local.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            body TEXT NOT NULL,
            kind TEXT NOT NULL,
            created_at INTEGER NOT NULL
        )""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun add(title: String, body: String, kind: String): Long {
        val values = ContentValues().apply {
            put("title", title); put("body", body); put("kind", kind); put("created_at", System.currentTimeMillis())
        }
        return writableDatabase.insert("items", null, values)
    }
    fun all(kind: String? = null): List<FridayItem> {
        val result = mutableListOf<FridayItem>()
        val cursor = if (kind == null) readableDatabase.rawQuery("SELECT * FROM items ORDER BY created_at DESC", null)
            else readableDatabase.rawQuery("SELECT * FROM items WHERE kind=? ORDER BY created_at DESC", arrayOf(kind))
        cursor.use {
            while (it.moveToNext()) result += FridayItem(
                it.getLong(it.getColumnIndexOrThrow("id")),
                it.getString(it.getColumnIndexOrThrow("title")),
                it.getString(it.getColumnIndexOrThrow("body")),
                it.getString(it.getColumnIndexOrThrow("kind")),
                it.getLong(it.getColumnIndexOrThrow("created_at"))
            )
        }
        return result
    }
    fun delete(id: Long) { writableDatabase.delete("items", "id=?", arrayOf(id.toString())) }
}
