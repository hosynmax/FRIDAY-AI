package com.friday.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

private val Navy = Color(0xFF080D1B)
private val Panel = Color(0xFF111B32)
private val Electric = Color(0xFF46C8FF)
private val Violet = Color(0xFF9A70FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FridayApp() }
    }
}

data class ChatLine(val fromFriday: Boolean, val text: String)

@Composable
fun FridayApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val db = remember { FridayDatabase(context) }
    val actions = remember { FridayActions(context) }
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    val preferences = remember { context.getSharedPreferences("friday_settings", android.content.Context.MODE_PRIVATE) }
    var backendUrl by remember { mutableStateOf(preferences.getString("backend_url", "https://YOUR-SERVER-DOMAIN") ?: "https://YOUR-SERVER-DOMAIN") }
    DisposableEffect(actions, db) {
        onDispose { actions.close(); db.close() }
    }
    var showSettings by remember { mutableStateOf(false) }
    var isBusy by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf("chat") }
    var refresh by remember { mutableIntStateOf(0) }
    val messages = remember { mutableStateListOf(ChatLine(true, "سلام! من FRIDAY هستم. چه کاری برات انجام بدم؟")) }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            input = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
        }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "فرمان خود را بگویید")
            }
            speechLauncher.launch(intent)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Electric, secondary = Violet,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF101B37), Navy, Color(0xFF080B16))))
                .padding(18.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("FRIDAY", fontSize = 28.sp, fontWeight = FontWeight.Black, color = Color.White, letterSpacing = 4.sp)
                    Text("YOUR PERSONAL AI INTELLIGENCE", fontSize = 9.sp, color = Electric, letterSpacing = 1.5.sp)
                }
                IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, contentDescription = "تنظیمات", tint = Electric) }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("chat" to "گفتگو", "notes" to "یادداشت‌ها", "tasks" to "وظایف").forEach { (key, label) ->
                    FilterChip(selected = mode == key, onClick = { mode = key }, label = { Text(label) })
                }
            }
            Spacer(Modifier.height(14.dp))
            if (mode == "chat") {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(128.dp).background(
                        Brush.radialGradient(listOf(Color(0x6658CFFF), Color(0x223C54FF), Color.Transparent)),
                        RoundedCornerShape(100.dp)), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(86.dp).background(
                            Brush.linearGradient(listOf(Color(0xFF2366A8), Color(0xFF633FC0), Color(0xFF101B35))),
                            RoundedCornerShape(100.dp)), contentAlignment = Alignment.Center) {
                            Text("F", fontSize = 42.sp, fontWeight = FontWeight.Light, color = Color.White)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("در خدمتم.", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(messages) { line ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.fromFriday) Arrangement.Start else Arrangement.End) {
                            Surface(color = if (line.fromFriday) Panel else Color(0xFF17365B), shape = RoundedCornerShape(16.dp)) {
                                Text(line.text, Modifier.padding(14.dp), color = Color.White)
                            }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                        placeholder = { Text("پیامت رو بنویس…", color = Color.LightGray) },
                        shape = RoundedCornerShape(18.dp), singleLine = true
                    )
                    IconButton(onClick = {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            speechLauncher.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
                            })
                        } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }) { Icon(Icons.Default.Mic, contentDescription = "گفتار", tint = Electric) }
                    IconButton(enabled = !isBusy, onClick = {
                        val text = input.trim()
                        if (text.isNotEmpty()) {
                            messages.add(ChatLine(false, text)); input = ""; isBusy = true
                            scope.launch {
                                val reply = runCatching { FridayApi(backendUrl.trim()).ask(text) }
                                    .getOrElse { "اتصال برقرار نشد: ${it.message ?: "خطای شبکه"}" }
                                messages.add(ChatLine(true, reply)); actions.speak(reply); isBusy = false
                            }
                        }
                    }) { Icon(Icons.Default.Send, contentDescription = "ارسال", tint = Violet) }
                }
                if (isBusy) LinearProgressIndicator(Modifier.fillMaxWidth())
            } else {
                val kind = if (mode == "notes") "note" else "task"
                val entries = remember(refresh, mode) { db.all(kind) }
                var title by remember(mode) { mutableStateOf("") }
                var body by remember(mode) { mutableStateOf("") }
                Text(if (mode == "notes") "یادداشت‌های من" else "فهرست وظایف", color = Electric, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("عنوان") })
                OutlinedTextField(body, { body = it }, Modifier.fillMaxWidth(), label = { Text("توضیحات") })
                Button(onClick = {
                    if (title.isNotBlank()) { db.add(title, body, kind); title = ""; body = ""; refresh++ }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (mode == "notes") "ذخیره یادداشت" else "افزودن وظیفه") }
                LazyColumn(Modifier.weight(1f)) {
                    items(entries, key = { it.id }) { entry ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(entry.title, fontWeight = FontWeight.Bold)
                                    Text(entry.body, color = Color.LightGray)
                                }
                                TextButton(onClick = { db.delete(entry.id); refresh++ }) { Text("حذف") }
                            }
                        }
                    }
                }
            }
            Text("نسخه توسعه‌ای • برای AI، آدرس Backend را در تنظیمات وارد کنید.", color = Color(0xFF9CAAC3), fontSize = 10.sp)
        }

        if (showSettings) AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("تنظیمات اتصال FRIDAY") },
            text = {
                Column {
                    Text("آدرس Backend (بدون کلید API):")
                    OutlinedTextField(backendUrl, { backendUrl = it }, singleLine = true)
                    Text("آدرس سرور باید HTTPS باشد؛ ابتدا Backend را روی سرور خودتان منتشر کنید.", fontSize = 11.sp)
                }
            },
            confirmButton = { TextButton(onClick = { preferences.edit().putString("backend_url", backendUrl.trim().trimEnd('/')).apply(); showSettings = false }) { Text("ذخیره") } }
        )
    }
}
