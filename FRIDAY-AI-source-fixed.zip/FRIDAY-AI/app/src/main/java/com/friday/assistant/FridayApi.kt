package com.friday.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class FridayApi(private val baseUrl: String) {
    suspend fun ask(message: String): String = withContext(Dispatchers.IO) {
        val connection = (URL("$baseUrl/v1/chat").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 45000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
        }
        try {
            connection.outputStream.use {
                it.write(JSONObject().put("message", message).toString().toByteArray(Charsets.UTF_8))
            }
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            val json = JSONObject(body)
            if (connection.responseCode !in 200..299) {
                "خطای سرور: ${json.optString("error", "unknown_error")}"
            } else json.optString("reply", "پاسخی دریافت نشد.")
        } finally { connection.disconnect() }
    }
}
